import React from 'react';

function About() {
    return ( <div className='page' >
    <h4>About Component</h4>
        <div className="pageContent" >
            We are a great company that loves its employees...
        </div>
    </div> );
}

export default About;
