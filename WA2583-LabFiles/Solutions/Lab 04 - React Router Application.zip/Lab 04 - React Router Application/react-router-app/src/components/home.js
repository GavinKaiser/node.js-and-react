import React from 'react';

function Home() {
    return ( <div className='page' >
    <h4>Home Component</h4>
        <div className="pageContent" >
            This is the Home page!
        </div>
    </div> );
}

export default Home;
