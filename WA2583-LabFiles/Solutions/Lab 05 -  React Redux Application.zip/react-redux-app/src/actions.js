export function setSelectedArticle(index){
    return {
        type: "SET_SELECTED_ARTICLE",
        index: index
    };
}