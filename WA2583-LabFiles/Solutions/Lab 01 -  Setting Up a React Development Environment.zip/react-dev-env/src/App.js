import './App.css';

function App() {
  return (
    <div id='main' >
      <h1>My App</h1>
    </div>
  );
}

export default App;
